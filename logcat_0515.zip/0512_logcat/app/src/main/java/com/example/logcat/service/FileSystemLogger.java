package com.example.logcat.service;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;

import com.example.logcat.util.FileActivityDetector;
import com.example.logcat.manager.HashGenerator;
import com.example.logcat.manager.LogHandler;
import com.example.logcat.manager.ServerTransmitter;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class FileSystemLogger extends Service {
    private static final String TAG = "FileLoggingService";

    private HashGenerator hashGenerator;
    private LogHandler logHandler;
    private ServerTransmitter serverTransmitter;
    private String serverTimestamp;

    // 여러 디렉토리 감시용
    private final List<FileActivityDetector> observers = new ArrayList<>();

    @Override
    public void onCreate() {
        super.onCreate();

        hashGenerator = new HashGenerator();
        serverTransmitter = new ServerTransmitter(this);
        logHandler = new LogHandler(this, serverTransmitter, "FileLog.txt");
        logHandler.initializeLogFile();

        // 외부 저장소 루트부터 재귀적으로 감시 시작
        File rootDirectory = new File("/storage/emulated/0/");
        watchAllRecursively(rootDirectory);

        Log.d(TAG, "FileLoggingService started and monitoring file system recursively.");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        for (FileActivityDetector observer : observers) {
            observer.stopWatching();
        }
        observers.clear();
        Log.d(TAG, "FileLoggingService stopped all observers.");
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    /**
     * 재귀적으로 하위 모든 디렉토리를 감시
     */
    private void watchAllRecursively(File dir) {
        if (dir == null || !dir.isDirectory()) return;

        // 숨김 디렉터리는 감시 제외
        if (dir.getName().startsWith(".")) return;

        FileActivityDetector observer = new FileActivityDetector(dir);
        observer.setLogMessageListener(this::sendLogMessage);
        observer.startWatching();
        observers.add(observer);

        File[] children = dir.listFiles();
        if (children != null) {
            for (File child : children) {
                if (child.isDirectory()) {
                    watchAllRecursively(child);
                }
            }
        }
    }

    /**
     * FileActivityDetector로부터 전달받은 로그 메시지를 처리
     */
    private void sendLogMessage(String message) throws IOException, NoSuchAlgorithmException {
        String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());
        serverTimestamp = ServerTransmitter.getServerTimestamp();

        String messageForLog = timestamp + " " + message + " ; serverTimestamp: " + serverTimestamp + "\n";

        logHandler.appendToLogFile(messageForLog);

        Path logFilePath = logHandler.getLogFilePath();
        String hash = hashGenerator.generateSHA256HashFromFile(logFilePath);
        logHandler.updateHashFile(hash);

        logHandler.checkFileSizeAndHandle(logHandler.getFilename());
    }
}
